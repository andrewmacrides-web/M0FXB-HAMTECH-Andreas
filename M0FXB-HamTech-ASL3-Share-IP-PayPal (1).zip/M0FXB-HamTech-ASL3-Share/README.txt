M0FXB HamTech Dashboard - ASL3 Share Package

This package contains the web dashboards captured from the working ASL3 node,
including the HamTech dashboard and the other dashboard directories present in
/var/www/html at the time the package was created.

INSTALL
1. Copy this entire extracted folder to the ASL3 node.
2. cd into the folder.
3. Run: sudo bash install.sh
4. Enter YOUR AllStar node number when prompted.
5. Choose the dashboard web username/password when prompted.
6. Open the IP address printed by the installer in a browser.

IMPORTANT
- The installer backs up the current /var/www/html first.
- No .htpasswd from the source node is included.
- The installer creates a fresh dashboard password on the destination node.
- The installer updates HamTech's node-specific stats links automatically.
- Use the web login over a trusted LAN or VPN; HTTP Basic Auth is not encrypted.

UPDATE: Dashboard now automatically displays the ASL3 web server IP address in the LCD header.
