#!/usr/bin/env bash
set -euo pipefail

WEBROOT=/var/www/html
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$SCRIPT_DIR/payload/html"

if [[ $EUID -ne 0 ]]; then
  echo "Please run with sudo: sudo bash install.sh"
  exit 1
fi
[[ -d "$PAYLOAD" ]] || { echo "ERROR: payload/html not found"; exit 1; }

printf '\nM0FXB HamTech Dashboard - ASL3 Share Installer\n\n'
read -rp "Enter this ASL3 node number: " NODE
[[ "$NODE" =~ ^[0-9]+$ ]] || { echo "Node number must contain digits only."; exit 1; }
read -rp "Dashboard title [M0FXB ALLSTAR DASH]: " TITLE
TITLE="${TITLE:-M0FXB ALLSTAR DASH}"
read -rp "Dashboard web username [admin]: " WEBUSER
WEBUSER="${WEBUSER:-admin}"
[[ "$WEBUSER" =~ ^[A-Za-z0-9._-]+$ ]] || { echo "Invalid username."; exit 1; }

echo "Installing required web packages..."
apt-get update --allow-releaseinfo-change
apt-get install -y apache2 libapache2-mod-php apache2-utils

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/var/backups/m0fxb-webroot-$STAMP"
if [[ -d "$WEBROOT" ]] && [[ -n "$(ls -A "$WEBROOT" 2>/dev/null || true)" ]]; then
  echo "Backing up existing web root to $BACKUP"
  mkdir -p "$BACKUP"
  cp -a "$WEBROOT/." "$BACKUP/"
fi

mkdir -p "$WEBROOT"
cp -a "$PAYLOAD/." "$WEBROOT/"
rm -f "$WEBROOT/.htpasswd" "$WEBROOT/.buttons.ini.swp"

cat > "$WEBROOT/config.ini" <<CFG
[node]
number = $NODE
title = "$TITLE"
CFG

# Update the two HamTech stats links to the node entered above.
if [[ -f "$WEBROOT/buttons.ini" ]]; then
  sed -Ei \
    -e "s#https://stats\.allstarlink\.org/stats/[0-9]+/networkMap#https://stats.allstarlink.org/stats/$NODE/networkMap#g" \
    -e "s#https://stats\.allstarlink\.org/nodeinfo\.cgi\?node=[0-9]+#https://stats.allstarlink.org/nodeinfo.cgi?node=$NODE#g" \
    "$WEBROOT/buttons.ini"
fi

cat > "$WEBROOT/.htaccess" <<HT
DirectoryIndex index.php
<FilesMatch "^(index|control)\\.php$">
AuthName "$TITLE"
AuthType Basic
AuthUserFile $WEBROOT/.htpasswd
Require valid-user
</FilesMatch>
HT

echo
echo "Set the password for dashboard web user '$WEBUSER':"
htpasswd -c "$WEBROOT/.htpasswd" "$WEBUSER"
chown root:www-data "$WEBROOT/.htpasswd"
chmod 640 "$WEBROOT/.htpasswd"

echo "www-data ALL=(root) NOPASSWD: /usr/sbin/asterisk" > /etc/sudoers.d/m0fxb-hamtech-dashboard
chmod 440 /etc/sudoers.d/m0fxb-hamtech-dashboard
visudo -cf /etc/sudoers.d/m0fxb-hamtech-dashboard >/dev/null

cat > /etc/apache2/conf-available/m0fxb-hamtech-dashboard.conf <<APACHE
<Directory $WEBROOT>
    AllowOverride All
    Require all granted
</Directory>
APACHE
a2enconf m0fxb-hamtech-dashboard >/dev/null

# Enable standard ASL3 Disconnect All mapping when the stock commented entry exists.
RPT=/etc/asterisk/rpt.conf
RESTART_ASTERISK=0
if [[ -f "$RPT" ]] && grep -Eq '^;[[:space:]]*806[[:space:]]*=[[:space:]]*ilink,6' "$RPT"; then
  cp -a "$RPT" "$RPT.m0fxb-backup-$STAMP"
  sed -Ei 's/^;[[:space:]]*806[[:space:]]*=[[:space:]]*ilink,6/806 = ilink,6/' "$RPT"
  RESTART_ASTERISK=1
fi

apache2ctl configtest
systemctl enable --now apache2
systemctl restart apache2
if [[ "$RESTART_ASTERISK" == 1 ]]; then
  systemctl restart asterisk
fi

IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
echo
echo "Installation complete."
echo "Node: $NODE"
echo "Dashboard user: $WEBUSER"
[[ -n "${IP:-}" ]] && echo "Open: http://$IP/"
echo "Your previous web root backup is: $BACKUP"
echo "Note: Basic Auth over HTTP should be used only on a trusted LAN/VPN."
