<?php

$config = parse_ini_file('config.ini', true);
$nodeNumber = isset($config['node']['number']) ? $config['node']['number'] : '59398';
$nodeTitle = isset($config['node']['title']) ? $config['node']['title'] : 'M0FXB';

$buttons = parse_ini_file('buttons.ini', true);

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo htmlspecialchars($nodeTitle); ?> | Transceiver Node <?php echo htmlspecialchars($nodeNumber); ?></title>
        <meta name="description" content="<?php echo htmlspecialchars($nodeTitle); ?> - AllStarLink Ham Radio Control Panel">
        <meta name="robots" content="noindex, nofollow">
        <meta name="author" content="M0NFI, G7RPG, G4IYT">
        <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
        <link rel="icon" href="favicon.ico" type="image/x-icon">
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="rig-wrapper">
            <!-- Main Radio Transceiver Chassis -->
            <div class="rig-chassis">
                <!-- Top Bezel / Rack Screws & Rig Badge -->
                <div class="rig-top-bar">
                    <div class="hex-screw top-left"></div>
                    <div class="rig-brand">
                        <span class="brand-name">M0FXB HamTech Dashboard</span>
                        <span class="model-badge">DSP-<?php echo htmlspecialchars($nodeNumber); ?> PRO</span>
                        <span class="model-desc">ALLSTARLINK DIGITAL TRANSCEIVER</span>
                    </div>
                    <div class="rig-power-section">
                        <div class="power-indicator">
                            <span class="power-led"></span>
                            <span class="power-label">PWR / READY</span>
                        </div>
                    </div>
                    <div class="hex-screw top-right"></div>
                </div>

                <!-- Upper Deck: LCD Display + VFO Tuning Dial + Controls -->
                <div class="rig-upper-deck">
                    <!-- Main LCD / TFT Transceiver Screen -->
                    <div class="lcd-screen-housing">
                        <div class="lcd-screen" id="lcd-screen">
                            <!-- LCD Top Header Bar -->
                            <div class="lcd-header-bar">
                                <span class="lcd-tag">NODE: <strong><?php echo htmlspecialchars($nodeNumber); ?></strong></span>
                                <span class="lcd-tag lcd-mem-highlight" id="lcd-mem-tag">VFO-A</span>
                                <span class="lcd-tag">MODE: <strong>FM-ASL</strong></span>
                                <span class="lcd-tag">PL: 103.5Hz</span>
                            </div>

                            <!-- Main Frequency / Callsign Readout -->
                            <div class="lcd-main-readout">
                                <div class="lcd-callsign" id="lcd-callsign"><?php echo htmlspecialchars($nodeTitle); ?></div>
                                <div class="lcd-channel-meta">
                                    <span class="lcd-subtext" id="lcd-active-title">STANDBY</span>
                                    <span class="lcd-frequency" id="lcd-active-code">430.000.00</span>
                                </div>
                            </div>

                            <!-- S-Meter / RF Power Display -->
                            <div class="lcd-smeter-container">
                                <div class="smeter-labels">
                                    <span>S 1</span><span>3</span><span>5</span><span>7</span><span>9</span>
                                    <span class="smeter-peak">+20</span><span class="smeter-peak">+40</span><span class="smeter-peak">+60 dB</span>
                                </div>
                                <div class="smeter-bar" id="smeter-bar">
                                    <div class="smeter-segment active-low"></div>
                                    <div class="smeter-segment active-low"></div>
                                    <div class="smeter-segment active-low"></div>
                                    <div class="smeter-segment active-low"></div>
                                    <div class="smeter-segment active-mid"></div>
                                    <div class="smeter-segment active-mid"></div>
                                    <div class="smeter-segment active-mid"></div>
                                    <div class="smeter-segment active-high"></div>
                                    <div class="smeter-segment active-high"></div>
                                    <div class="smeter-segment active-peak"></div>
                                    <div class="smeter-segment active-peak"></div>
                                    <div class="smeter-segment active-peak"></div>
                                </div>
                            </div>

                            <!-- Status Flags / Annunciators -->
                            <div class="lcd-flags-bar">
                                <div class="lcd-flag flag-rx active" id="flag-rx">● RX</div>
                                <div class="lcd-flag flag-tx" id="flag-tx">● TX</div>
                                <div class="lcd-flag flag-sql active">SQL</div>
                                <div class="lcd-flag flag-link active" id="flag-link">NET-LINK</div>
                                <div class="lcd-flag flag-asl">ASL3</div>
                            </div>

                            <!-- Dynamic LCD Status Line -->
                            <div class="lcd-status-marquee">
                                <span class="marquee-icon">&gt;&gt;</span>
                                <span class="marquee-text" id="lcd-marquee">STANDBY // READY FOR COMMANDS</span>
                            </div>
                        </div>
                    </div>

                    <!-- Right Side: VFO Tuning Dial & Rotary Knobs -->
                    <div class="rig-vfo-deck">
                        <!-- Big Metallic VFO Dial -->
                        <div class="vfo-dial-wrapper">
                            <div class="vfo-dial-bezel">
                                <div class="vfo-dial" id="vfo-dial" title="Rotate VFO Dial (Click or Scroll)">
                                    <div class="vfo-knurling"></div>
                                    <div class="vfo-inner-disc">
                                        <div class="vfo-dimple"></div>
                                    </div>
                                </div>
                            </div>
                            <span class="vfo-label">MAIN TUNING</span>
                        </div>

                        <!-- Secondary Controls -->
                        <div class="rig-knobs-row">
                            <div class="rotary-knob-wrapper">
                                <div class="rotary-knob knob-af"><div class="knob-line"></div></div>
                                <span class="knob-label">AF GAIN</span>
                            </div>
                            <div class="rotary-knob-wrapper">
                                <div class="rotary-knob knob-sql"><div class="knob-line"></div></div>
                                <span class="knob-label">SQL / RF</span>
                            </div>
                            <div class="mic-jack-wrapper" title="8-Pin Transceiver Mic Jack">
                                <div class="mic-jack">
                                    <div class="mic-pin p1"></div><div class="mic-pin p2"></div>
                                    <div class="mic-pin p3"></div><div class="mic-pin p4"></div>
                                    <div class="mic-pin p5"></div><div class="mic-pin p6"></div>
                                    <div class="mic-pin p7"></div><div class="mic-pin p8"></div>
                                </div>
                                <span class="knob-label">MIC</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Lower Deck: Keypad & Memory Channels (The Action Buttons) -->
                <div class="rig-keypad-deck">
                    <div class="keypad-header">
                        <span class="keypad-title">MEMORY CHANNELS & FUNCTION KEYS</span>
                        <div class="speaker-grille">
                            <span></span><span></span><span></span><span></span><span></span>
                            <span></span><span></span><span></span><span></span><span></span>
                        </div>
                    </div>

                    <div class="buttons-grid">
                        <?php 
                        $channelIndex = 1;
                        foreach($buttons as $key => $btn): 
                            $colorClass = isset($btn['color']) ? 'btn-' . htmlspecialchars($btn['color']) : 'btn-blue';
                            $title = isset($btn['title']) ? $btn['title'] : $key;
                            $hasHref = isset($btn['href']);
                            $hasCmds = isset($btn['cmds']);
                            $cmdLabel = '';
                            if ($hasCmds) {
                                $cmdList = (array)$btn['cmds'];
                                $cmdLabel = implode(' ', $cmdList);
                            }
                            $chTag = sprintf("M%02d", $channelIndex++);
                        ?>
                            <div class="rig-key-socket">
                                <?php if ($hasHref): ?>
                                    <a href="<?php echo htmlspecialchars($btn['href']); ?>" target="_blank" rel="noopener noreferrer" class="rig-key <?php echo $colorClass; ?> key-link" id="<?php echo htmlspecialchars($key); ?>" data-title="<?php echo htmlspecialchars($title); ?>" data-type="LINK" data-ch="<?php echo $chTag; ?>">
                                        <div class="key-led led-<?php echo htmlspecialchars(isset($btn['color']) ? $btn['color'] : 'blue'); ?>"></div>
                                        <div class="key-inner">
                                            <div class="key-meta">
                                                <span class="key-ch">[<?php echo $chTag; ?>]</span>
                                                <span class="key-ext">EXT ↗</span>
                                            </div>
                                            <div class="key-label"><?php echo htmlspecialchars($title); ?></div>
                                        </div>
                                    </a>
                                <?php else: ?>
                                    <button type="button" class="rig-key <?php echo $colorClass; ?> key-action" id="<?php echo htmlspecialchars($key); ?>" data-cmd="<?php echo htmlspecialchars($key); ?>" data-title="<?php echo htmlspecialchars($title); ?>" data-code="<?php echo htmlspecialchars($cmdLabel); ?>" data-ch="<?php echo $chTag; ?>">
                                        <div class="key-led led-<?php echo htmlspecialchars(isset($btn['color']) ? $btn['color'] : 'green'); ?>"></div>
                                        <div class="key-inner">
                                            <div class="key-meta">
                                                <span class="key-ch">[<?php echo $chTag; ?>]</span>
                                                <?php if (!empty($cmdLabel)): ?>
                                                    <span class="key-code"><?php echo htmlspecialchars($cmdLabel); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="key-label"><?php echo htmlspecialchars($title); ?></div>
                                        </div>
                                    </button>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Bottom Bezel -->
                <div class="rig-bottom-bar">
                    <div class="hex-screw bottom-left"></div>
                    <div class="rig-footer-text">HERTS REPEATER GROUP &bull; ALLSTARLINK NODE <?php echo htmlspecialchars($nodeNumber); ?></div>
                    <div class="hex-screw bottom-right"></div>
                </div>
            </div>
        </div>

        <div id="toast-container" class="toast-container" aria-live="polite"></div>

        <script>
            let currentVfoAngle = 0;
            const vfoDial = document.getElementById('vfo-dial');
            const lcdMarquee = document.getElementById('lcd-marquee');
            const lcdMemTag = document.getElementById('lcd-mem-tag');
            const lcdActiveTitle = document.getElementById('lcd-active-title');
            const lcdActiveCode = document.getElementById('lcd-active-code');
            const flagTx = document.getElementById('flag-tx');
            const flagRx = document.getElementById('flag-rx');
            const smeterSegments = document.querySelectorAll('.smeter-segment');

            // Interactive VFO Dial Rotation
            function rotateVfo(delta) {
                currentVfoAngle = (currentVfoAngle + delta) % 360;
                vfoDial.style.transform = `rotate(${currentVfoAngle}deg)`;
            }

            if (vfoDial) {
                vfoDial.addEventListener('wheel', (e) => {
                    e.preventDefault();
                    rotateVfo(e.deltaY > 0 ? 15 : -15);
                });

                let isDragging = false;
                let startX = 0;
                vfoDial.addEventListener('mousedown', (e) => {
                    isDragging = true;
                    startX = e.clientX;
                });
                window.addEventListener('mousemove', (e) => {
                    if (isDragging) {
                        const delta = (e.clientX - startX) * 2;
                        rotateVfo(delta);
                        startX = e.clientX;
                    }
                });
                window.addEventListener('mouseup', () => { isDragging = false; });
            }

            function showToast(message, type = 'info') {
                const container = document.getElementById('toast-container');
                const toast = document.createElement('div');
                toast.className = `toast toast-${type}`;
                toast.innerHTML = `<span class="toast-icon">${type === 'success' ? '✓' : (type === 'error' ? '✕' : 'ℹ')}</span> <span class="toast-message">${message}</span>`;
                container.appendChild(toast);

                setTimeout(() => { toast.classList.add('toast-show'); }, 10);
                setTimeout(() => {
                    toast.classList.remove('toast-show');
                    setTimeout(() => {
                        if (toast.parentNode) toast.parentNode.removeChild(toast);
                    }, 300);
                }, 3000);
            }

            // Update LCD Display based on clicked channel
            function updateLcdChannel(title, code, chTag, cmd) {
                // Flash Transmit State
                flagRx.classList.remove('active');
                flagTx.classList.add('active');
                smeterSegments.forEach(seg => seg.classList.add('illuminated-full'));

                // Immediate Transmit Announcement
                lcdMarquee.innerText = `TX: [${chTag}] ${code ? '[' + code + '] ' : ''}${title.toUpperCase()} DISPATCHED`;
                lcdMarquee.style.color = '#ff4444';

                // Update Main Display Readouts
                if (cmd === 'disconnect_all' || code === '*73') {
                    lcdMemTag.innerText = 'STANDBY';
                    lcdActiveTitle.innerText = 'DISCONNECTED';
                    lcdActiveTitle.style.color = '#ff4444';
                    lcdActiveCode.innerText = 'NO ACTIVE LINKS';

                    // Clear active selection highlights
                    document.querySelectorAll('.rig-key').forEach(k => k.classList.remove('key-selected'));
                } else {
                    lcdMemTag.innerText = `CH: ${chTag}`;
                    lcdActiveTitle.innerText = title.toUpperCase();
                    lcdActiveTitle.style.color = '#ffb300';
                    lcdActiveCode.innerText = code ? `DTMF: ${code}` : 'ACTIVE';
                }

                // Settle back to active state after transmit burst
                setTimeout(() => {
                    flagTx.classList.remove('active');
                    flagRx.classList.add('active');
                    smeterSegments.forEach(seg => seg.classList.remove('illuminated-full'));

                    if (cmd === 'disconnect_all' || code === '*73') {
                        lcdMarquee.innerText = 'STANDBY // ALL RF LINKS DISCONNECTED';
                        lcdMarquee.style.color = '#00e5ff';
                    } else {
                        lcdMarquee.innerText = `ONLINE // CONNECTED TO ${title.toUpperCase()}`;
                        lcdMarquee.style.color = '#00e5ff';
                    }
                }, 1400);
            }

            document.querySelectorAll('.key-action').forEach(btn => {
                btn.addEventListener('click', function () {
                    const cmd = this.getAttribute('data-cmd');
                    const title = this.getAttribute('data-title');
                    const code = this.getAttribute('data-code');
                    const chTag = this.getAttribute('data-ch');

                    // Button depression haptics
                    this.classList.add('key-pressed');
                    setTimeout(() => this.classList.remove('key-pressed'), 250);

                    // Set persistent selected state on the key
                    if (cmd !== 'disconnect_all' && code !== '*73') {
                        document.querySelectorAll('.rig-key').forEach(k => k.classList.remove('key-selected'));
                        this.classList.add('key-selected');
                    }

                    updateLcdChannel(title, code, chTag, cmd);
                    showToast(`Sending: [${chTag}] ${title} ${code ? '(' + code + ')' : ''}`, 'info');

                    fetch(`control.php?cmd=${encodeURIComponent(cmd)}`)
                        .then(response => {
                            if (response.ok) {
                                showToast(`Executed: ${title}`, 'success');
                            } else {
                                showToast(`Error executing: ${title}`, 'error');
                            }
                        })
                        .catch(err => {
                            showToast(`Failed to dispatch command to Asterisk`, 'error');
                        });
                });
            });
        </script>
    </body>
</html>
